
function addTokens(input, tokens){
 if(!valideaza(input)) {
   throw new Error("Invalid input"); //Input should be a string  
}
//Input trebuie sa aiba cel putin 6 caractere ca si lungime. Daca dimensiunea 
//input-ului este mai mica de 6, aruncati Error cu mesajul : Input should have at leat 
//6 characters
 if(input.length < 6) {
   throw new Error("Input should have at least 6 characters");
 }
//tokens este un vector de elemente cu urmatorul format: {tokenName: string}.
//Daca urmatorul format nu este respectat, aruncati Error cu urmatorul mesaj:
//Invalid array format
  for (var i = 0; i < tokens.length; i++) {
    if(!valideaza(tokens[i].tokenName)){
        throw new Error('Invalid array format');
    }
}
}
const app = {
    addTokens: addTokens
}

function valideaza(inp) {
    return (typeof inp==="string" || inp instanceof String);
}
module.exports = app;